import 'package:flutter/material.dart';

/// WithOn UI — 캡처처럼 부드러운 살몬/파스텔 오렌지
class AppColors {
  // 메인 오렌지 (부드러운 살몬·코랄 톤)
  static const Color primary = Color(0xFFD99F91);
  static const Color primaryLight = Color(0xFFE5B5A8);
  static const Color primaryDark = Color(0xFFC98B7A);

  // Background (HTML phone frame #F2F2F7 톤)
  static const Color bgLight = Color(0xFFF2F2F7);
  static const Color bgWarm = Color(0xFFF5EDE0);
  static const Color bgDeep = Color(0xFFEFE6D6);

  // Text
  static const Color textDark = Color(0xFF5A4E42);
  static const Color textMedium = Color(0xFF8B7D6B);
  static const Color textLight = Color(0xFFA09484);
  static const Color textMuted = Color(0xFFB8ADA0);

  // Border
  static const Color border = Color(0xFFDDD4C8);
  static const Color borderLight = Color(0xFFE8DCC8);

  // 기도 상태용 (Chip 배경/강조 톤) — primary와 조화
  static const Color statusPraying = Color(0xFFD99F91);
  static const Color statusWaiting = Color(0xFFA0937D);
  static const Color statusResponded = Color(0xFF7B9E6B);
  static const Color statusPartial = Color(0xFF8FA4B0);
  static const Color statusGratitude = Color(0xFFD4A574);

  // HTML 서브 텍스트
  static const Color navInactive = Color(0xFF8E8E93);
}

class AppTheme {
  // 기존 참조 호환용 별칭
  static const Color primaryColor = AppColors.primary;
  static const Color primaryDark = AppColors.primaryDark;
  static const Color backgroundLight = AppColors.bgLight;
  static const Color cardBackground = Colors.white;
  static const Color accentYellow = AppColors.statusGratitude;
  static const Color textMain = AppColors.textDark;
  static const Color textSubtle = AppColors.textMedium;

  static ThemeData get lightTheme {
    final base = ThemeData.light();
    return base.copyWith(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.bgLight,
      primaryColor: AppColors.primary,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.primary,
        secondary: AppColors.primaryLight,
        surface: AppColors.bgLight,
        onPrimary: Colors.white,
        onSurface: AppColors.textDark,
      ),
      appBarTheme: const AppBarTheme(
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: AppColors.textDark,
        centerTitle: false,
        iconTheme: IconThemeData(color: AppColors.textLight),
        titleTextStyle: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w400,
          color: AppColors.textDark,
          letterSpacing: 1,
        ),
      ),
      cardTheme: CardThemeData(
        color: cardBackground,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,
        elevation: 0,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(20)),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      textTheme: base.textTheme.apply(
        bodyColor: AppColors.textDark,
        displayColor: AppColors.textDark,
        fontFamily: 'Sans',
      ).copyWith(
        bodyLarge: base.textTheme.bodyLarge?.copyWith(
          color: AppColors.textDark,
          height: 1.6,
        ),
        bodyMedium: base.textTheme.bodyMedium?.copyWith(
          color: AppColors.textMedium,
          height: 1.7,
        ),
        bodySmall: base.textTheme.bodySmall?.copyWith(
          color: AppColors.textMuted,
          letterSpacing: 0.5,
        ),
        labelMedium: base.textTheme.labelMedium?.copyWith(
          color: AppColors.textLight,
          letterSpacing: 1,
        ),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: AppColors.primary,
        unselectedItemColor: AppColors.textMedium,
        selectedLabelStyle: TextStyle(fontWeight: FontWeight.w600),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          textStyle: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w500,
            letterSpacing: 1,
          ),
        ),
      ),
    );
  }
}
