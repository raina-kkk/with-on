import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../widgets/app_banner.dart';

/// HTML 목업 스타일 홈: 서머리 카드 + 나의 기도/소그룹 캐러셀
class HomePage extends StatelessWidget {
  const HomePage({
    super.key,
    required this.onNavigateToMyPrayer,
    required this.onNavigateToGroup,
    required this.onNavigateToProfile,
    this.onNotification,
    this.notificationCount,
  });

  final VoidCallback onNavigateToMyPrayer;
  final VoidCallback onNavigateToGroup;
  final VoidCallback onNavigateToProfile;
  final VoidCallback? onNotification;
  final int? notificationCount;

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      backgroundColor: AppColors.bgLight,
      body: Stack(
        children: [
          // 전체 영역 스크롤 + 상단 패딩 → 스크롤 시 콘텐츠가 배너 그라데이션 아래로 스며듦
          Positioned.fill(
            child: uid == null
                ? const Padding(
                    padding: EdgeInsets.only(top: AppBanner.totalHeight),
                    child: Center(child: Text('로그인 후 이용해 주세요.')),
                  )
                : ScrollConfiguration(
                    behavior: _NoScrollbarScrollBehavior(),
                    child: SingleChildScrollView(
                    padding: const EdgeInsets.only(
                      top: AppBanner.totalHeight,
                      left: 24,
                      right: 24,
                      bottom: 100,
                    ),
                    child: _HomeBody(
                      uid: uid,
                      onNavigateToMyPrayer: onNavigateToMyPrayer,
                      onNavigateToGroup: onNavigateToGroup,
                    ),
                  ),
                  ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: AppBanner(
              titleLeft: 'With',
              titleRight: 'On',
              subtitle: '함께 기도를 켜는 시간',
              onNotification: onNotification,
              onProfile: onNavigateToProfile,
              notificationCount: notificationCount,
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeBody extends StatelessWidget {
  const _HomeBody({
    required this.uid,
    required this.onNavigateToMyPrayer,
    required this.onNavigateToGroup,
  });

  final String uid;
  final VoidCallback onNavigateToMyPrayer;
  final VoidCallback onNavigateToGroup;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 10),
        _SummaryCard(uid: uid),
        const SizedBox(height: 14),
        _MyPrayerCarousel(uid: uid, onSeeAll: onNavigateToMyPrayer),
        const SizedBox(height: 14),
        _GroupPrayerCarousel(uid: uid, onSeeAll: onNavigateToGroup),
        const SizedBox(height: 14),
      ],
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.uid});

  final String uid;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('group_prayers')
          .where('owner_uid', isEqualTo: uid)
          .snapshots(),
      builder: (context, snapshot) {
        int total = 0;
        if (snapshot.hasData) {
          for (final doc in snapshot.data!.docs) {
            total += (doc.data()['hold_count'] as int?) ?? 0;
          }
        }
        return Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(28),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withValues(alpha: 0.3),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '지체들이 당신을 위해\n${total}번의 마음을 모았습니다.',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                  height: 1.25,
                ),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Icon(Icons.favorite_rounded,
                      color: Colors.white.withValues(alpha: 0.9), size: 16),
                  const SizedBox(width: 6),
                  Text(
                    '외 ${total > 0 ? total - 1 : 0}명이 기도 중',
                    style: TextStyle(
                      fontSize: 10,
                      color: Colors.white.withValues(alpha: 0.85),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({
    required this.icon,
    required this.title,
    required this.onSeeAll,
  });

  final IconData icon;
  final String title;
  final VoidCallback onSeeAll;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, size: 18, color: AppColors.primary),
          ),
          const SizedBox(width: 10),
          Text(
            title,
            style: const TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w700,
              color: AppColors.textDark,
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: onSeeAll,
            child: Text(
              '모두 보기 >',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: AppColors.textMedium,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

String _formatTimeAgo(DateTime date) {
  final diff = DateTime.now().difference(date);
  if (diff.inDays > 0) return '${diff.inDays}일 전';
  if (diff.inHours > 0) return '${diff.inHours}시간 전';
  if (diff.inMinutes > 0) return '${diff.inMinutes}분 전';
  return '방금 전';
}

class _MyPrayerCarousel extends StatelessWidget {
  const _MyPrayerCarousel({required this.uid, required this.onSeeAll});

  final String uid;
  final VoidCallback onSeeAll;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: FirebaseFirestore.instance
            .collection('prayers')
            .where('owner_uid', isEqualTo: uid)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SectionHeader(
                  icon: Icons.auto_awesome_rounded,
                  title: '나의 기도',
                  onSeeAll: onSeeAll,
                ),
                const SizedBox(height: 8),
                Container(
                  height: 128,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.border.withValues(alpha: 0.4)),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '기도 목록을 불러오는 데 실패했어요.\n잠시 후 다시 시도해 주세요.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, color: AppColors.textMedium),
                  ),
                ),
              ],
            );
          }
          if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SectionHeader(
                  icon: Icons.auto_awesome_rounded,
                  title: '나의 기도',
                  onSeeAll: onSeeAll,
                ),
                const SizedBox(height: 8),
                Container(
                  height: 128,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.border.withValues(alpha: 0.4)),
                  ),
                  alignment: Alignment.center,
                  child: const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              ],
            );
          }
          final allDocs = snapshot.data?.docs ?? [];
          final sorted = List<QueryDocumentSnapshot<Map<String, dynamic>>>.from(allDocs)
            ..sort((a, b) {
              final aAt = a.data()['created_at'];
              final bAt = b.data()['created_at'];
              final aDt = aAt is Timestamp ? aAt.toDate() : (aAt is DateTime ? aAt : DateTime(0));
              final bDt = bAt is Timestamp ? bAt.toDate() : (bAt is DateTime ? bAt : DateTime(0));
              return bDt.compareTo(aDt);
            });
          final top5 = sorted.take(5).toList();
          if (top5.isEmpty) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _SectionHeader(
                  icon: Icons.auto_awesome_rounded,
                  title: '나의 기도',
                  onSeeAll: onSeeAll,
                ),
                const SizedBox(height: 8),
                Container(
                  height: 128,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.border.withValues(alpha: 0.4)),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '아직 기록한 기도 제목이 없어요.\n첫 기도를 올려 보세요.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14,
                      color: AppColors.textMedium,
                    ),
                  ),
                ),
              ],
            );
          }
          return _MyPrayerCarouselPaged(top5: top5, onSeeAll: onSeeAll);
        },
      );
  }
}

class _MyPrayerCarouselPaged extends StatefulWidget {
  const _MyPrayerCarouselPaged({required this.top5, required this.onSeeAll});

  final List<QueryDocumentSnapshot<Map<String, dynamic>>> top5;
  final VoidCallback onSeeAll;

  @override
  State<_MyPrayerCarouselPaged> createState() => _MyPrayerCarouselPagedState();
}

class _MyPrayerCarouselPagedState extends State<_MyPrayerCarouselPaged> {
  late final PageController _pageController;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.88);
    _pageController.addListener(_onPageChanged);
  }

  void _onPageChanged() {
    final page = _pageController.page?.round() ?? 0;
    if (page != _currentPage && mounted) {
      setState(() => _currentPage = page);
    }
  }

  @override
  void dispose() {
    _pageController.removeListener(_onPageChanged);
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final top5 = widget.top5;
    const double symbolHeight = 32;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: [
              Container(
                width: symbolHeight,
                height: symbolHeight,
                decoration: BoxDecoration(
                  color: AppColors.primary.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(Icons.auto_awesome_rounded, size: 18, color: AppColors.primary),
              ),
              const SizedBox(width: 10),
              SizedBox(
                height: symbolHeight,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '나의 기도',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        height: 1.0,
                        color: AppColors.textDark,
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: List.generate(top5.length, (i) {
                        final isActive = i == _currentPage;
                        return Container(
                          margin: const EdgeInsets.only(right: 6),
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isActive
                                ? AppColors.primary
                                : AppColors.border.withValues(alpha: 0.6),
                          ),
                        );
                      }),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: widget.onSeeAll,
                child: Text(
                  '모두 보기 >',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textMedium,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 128,
          child: PageView.builder(
            controller: _pageController,
            itemCount: top5.length,
            itemBuilder: (context, index) {
              final data = top5[index].data();
              final title = (data['title'] as String?)?.trim() ?? '(제목 없음)';
              final content = (data['content'] as String?)?.trim() ?? '';
              final createdAt = data['created_at'];
              final created = createdAt is Timestamp
                  ? createdAt.toDate()
                  : (createdAt is DateTime ? createdAt : null);
              final timeAgo = created != null ? _formatTimeAgo(created) : '';
              final daysSinceCreated = created != null
                  ? (DateTime.now().difference(DateTime(created.year, created.month, created.day)).inDays + 1).clamp(1, 999)
                  : 1;

              return Padding(
                padding: const EdgeInsets.only(right: 12),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.border.withValues(alpha: 0.4)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.04),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        content.isNotEmpty ? '"$content"' : title,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 13,
                          height: 1.4,
                          color: AppColors.textDark.withValues(alpha: 0.9),
                          fontStyle: content.isNotEmpty ? FontStyle.italic : FontStyle.normal,
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '연속 ${daysSinceCreated}일 기도의 등불',
                            style: const TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: AppColors.primary,
                            ),
                          ),
                          Text(
                            timeAgo,
                            style: TextStyle(
                              fontSize: 10,
                              color: AppColors.textLight.withValues(alpha: 0.7),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _GroupPrayerCarousel extends StatelessWidget {
  const _GroupPrayerCarousel({required this.uid, required this.onSeeAll});

  final String uid;
  final VoidCallback onSeeAll;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .snapshots(),
      builder: (context, userSnap) {
        final groupIds = (userSnap.data?.data()?['group_ids'] as List<dynamic>?)
                ?.map((e) => e.toString())
                .toList() ??
            [];
        if (groupIds.isEmpty) {
          return _emptySection(context);
        }
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance
              .collection('group_prayers')
              .where('group_id', whereIn: groupIds.length > 10 ? groupIds.take(10).toList() : groupIds)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasError) return _emptySection(context);
            final allDocs = snapshot.data?.docs ?? [];
            final sorted = List<QueryDocumentSnapshot<Map<String, dynamic>>>.from(allDocs)
              ..sort((a, b) {
                final aAt = a.data()['created_at'];
                final bAt = b.data()['created_at'];
                final aDt = aAt is Timestamp ? aAt.toDate() : (aAt is DateTime ? aAt : DateTime(0));
                final bDt = bAt is Timestamp ? bAt.toDate() : (bAt is DateTime ? bAt : DateTime(0));
                return bDt.compareTo(aDt);
              });
            final top5 = sorted.take(5).toList();
            if (top5.isEmpty) return _emptySection(context);
            return _GroupPrayerCarouselPaged(top5: top5, onSeeAll: onSeeAll);
          },
        );
      },
    );
  }

  Widget _emptySection(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeader(
          icon: Icons.groups_rounded,
          title: '소그룹 기도',
          onSeeAll: onSeeAll,
        ),
        const SizedBox(height: 8),
        Container(
          height: 168,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.border.withValues(alpha: 0.4)),
          ),
          alignment: Alignment.center,
          child: Text(
            '소그룹에 참여하면\n함께 나눈 기도 제목을 볼 수 있어요.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, color: AppColors.textMedium),
          ),
        ),
      ],
    );
  }
}

class _GroupPrayerCarouselPaged extends StatefulWidget {
  const _GroupPrayerCarouselPaged({
    required this.top5,
    required this.onSeeAll,
  });

  final List<QueryDocumentSnapshot<Map<String, dynamic>>> top5;
  final VoidCallback onSeeAll;

  @override
  State<_GroupPrayerCarouselPaged> createState() => _GroupPrayerCarouselPagedState();
}

class _GroupPrayerCarouselPagedState extends State<_GroupPrayerCarouselPaged> {
  late final PageController _pageController;
  int _currentPage = 0;

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.88);
    _pageController.addListener(_onPageChanged);
  }

  void _onPageChanged() {
    final page = _pageController.page?.round() ?? 0;
    if (page != _currentPage && mounted) {
      setState(() => _currentPage = page);
    }
  }

  @override
  void dispose() {
    _pageController.removeListener(_onPageChanged);
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final top5 = widget.top5;
    const double symbolHeight = 32;
    final viewportWidth = MediaQuery.of(context).size.width - 48;
    final cardWidth = viewportWidth * 0.88 - 12;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: [
              Container(
                width: symbolHeight,
                height: symbolHeight,
                decoration: BoxDecoration(
                  color: AppColors.primary.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(Icons.groups_rounded, size: 18, color: AppColors.primary),
              ),
              const SizedBox(width: 10),
              SizedBox(
                height: symbolHeight,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '소그룹 기도',
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        height: 1.0,
                        color: AppColors.textDark,
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: List.generate(top5.length, (i) {
                        final isActive = i == _currentPage;
                        return Container(
                          margin: const EdgeInsets.only(right: 6),
                          width: 6,
                          height: 6,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: isActive
                                ? AppColors.primary
                                : AppColors.border.withValues(alpha: 0.6),
                          ),
                        );
                      }),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: widget.onSeeAll,
                child: Text(
                  '모두 보기 >',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: AppColors.textMedium,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 168,
          child: PageView.builder(
            controller: _pageController,
            itemCount: top5.length,
            itemBuilder: (context, index) {
              final gpDoc = top5[index];
              final data = gpDoc.data();
              final prayerId = data['prayer_id'] as String? ?? '';
              final groupId = data['group_id'] as String? ?? '';
              final holdCount = (data['hold_count'] as int?) ?? 0;
              return Padding(
                padding: const EdgeInsets.only(right: 12),
                child: _GroupPrayerCard(
                  prayerId: prayerId,
                  groupId: groupId,
                  holdCount: holdCount,
                  width: cardWidth,
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _GroupPrayerCard extends StatelessWidget {
  const _GroupPrayerCard({
    required this.prayerId,
    required this.groupId,
    required this.holdCount,
    required this.width,
  });

  final String prayerId;
  final String groupId;
  final int holdCount;
  final double width;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('prayers').doc(prayerId).snapshots(),
      builder: (context, snap) {
        final prayerData = snap.data?.data();
        final title = (prayerData?['title'] as String?)?.trim() ?? '(제목 없음)';
        final ownerUid = prayerData?['owner_uid'] as String? ?? '';
        final ownerNickname = (prayerData?['owner_nickname'] as String?)?.trim();

        return Container(
          width: width,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.border.withValues(alpha: 0.4)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: FutureBuilder<({String nickname, String groupName})>(
                      future: _fetchNicknameAndGroupName(ownerUid, ownerNickname, groupId),
                      builder: (context, asyncSnap) {
                        final nickname = asyncSnap.data?.nickname ?? '···';
                        final groupName = asyncSnap.data?.groupName ?? '···';
                        final firstLine = '$nickname | $groupName';
                        return Text(
                          firstLine,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textDark,
                          ),
                        );
                      },
                    ),
                  ),
                  Icon(Icons.favorite_rounded,
                      size: 14,
                      color: holdCount > 0 ? AppColors.primary : AppColors.textMuted),
                  const SizedBox(width: 4),
                  Text(
                    '$holdCount',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: holdCount > 0 ? AppColors.primary : AppColors.textMuted,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 13,
                  color: AppColors.textDark.withValues(alpha: 0.8),
                ),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () {},
                  style: TextButton.styleFrom(
                    backgroundColor: AppColors.bgDeep,
                    foregroundColor: AppColors.textMedium,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                  ),
                  child: const Text('자세히 보기', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

Future<({String nickname, String groupName})> _fetchNicknameAndGroupName(
  String ownerUid,
  String? ownerNickname,
  String groupId,
) async {
  String nickname = ownerNickname?.isNotEmpty == true ? ownerNickname! : '';
  String groupName = '';

  if (nickname.isEmpty && ownerUid.isNotEmpty) {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(ownerUid)
          .get();
      nickname = (userDoc.data()?['nickname'] as String?)?.trim() ?? '';
    } catch (_) {}
  }
  if (nickname.isEmpty) nickname = '(이름 없음)';

  if (groupId.isNotEmpty) {
    try {
      final groupDoc = await FirebaseFirestore.instance
          .collection('groups')
          .doc(groupId)
          .get();
      groupName = (groupDoc.data()?['name'] as String?)?.trim() ?? '';
    } catch (_) {}
  }
  if (groupName.isEmpty) groupName = '(소그룹)';

  return (nickname: nickname, groupName: groupName);
}

/// 홈 세로 스크롤 시 스크롤바 비표시
class _NoScrollbarScrollBehavior extends ScrollBehavior {
  @override
  Widget buildScrollbar(
    BuildContext context,
    Widget child,
    ScrollableDetails details,
  ) {
    return child;
  }
}
