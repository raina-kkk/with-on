import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/theme/app_theme.dart';
import '../../core/utils/week_utils.dart';
import '../widgets/app_banner.dart';

// ── 소그룹 멤버 시트/제거 (설정 화면에서도 사용) ──
Future<Map<String, String>> _fetchGroupMemberNicknames(
    List<String> uids) async {
  final result = <String, String>{};
  for (final uid in uids) {
    try {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get();
      result[uid] =
          (doc.data()?['nickname'] as String?)?.trim() ?? uid;
    } catch (_) {
      result[uid] = uid;
    }
  }
  return result;
}

Future<void> _removeMemberFromGroup({
  required BuildContext context,
  required String groupId,
  required String memberUid,
}) async {
  try {
    final now = DateTime.now();
    await FirebaseFirestore.instance.collection('groups').doc(groupId).update({
      'member_uids': FieldValue.arrayRemove([memberUid]),
      'updated_at': now,
    });
    await FirebaseFirestore.instance.collection('users').doc(memberUid).set(
      {
        'group_ids': FieldValue.arrayRemove([groupId]),
        'updated_at': now,
      },
      SetOptions(merge: true),
    );
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('선택하신 멤버를 소그룹에서 조용히 내보냈습니다.'),
        ),
      );
    }
  } catch (_) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              '멤버를 내보내는 중에 잠시 어려움이 있었습니다.\n조금 뒤에 다시 시도해 주시면 감사하겠습니다.'),
        ),
      );
    }
  }
}

void _openGroupMemberSheet({
  required BuildContext context,
  required String groupId,
  required String ownerUid,
  required List<String> memberUids,
  required String currentUid,
  required bool canManage,
}) {
  showModalBottomSheet<void>(
    context: context,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              canManage ? '소그룹 멤버 관리' : '소그룹 멤버 목록',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              canManage
                  ? '함께하고 있는 손길들을 조심스럽게 관리할 수 있습니다.\n필요할 때에만 신중하게 사용해 주세요.'
                  : '함께 기도하고 있는 소그룹 멤버들입니다.',
              style: Theme.of(ctx).textTheme.bodyMedium?.copyWith(
                    color: AppTheme.textSubtle,
                  ),
            ),
            const SizedBox(height: 16),
            Flexible(
              child: FutureBuilder<Map<String, String>>(
                future: _fetchGroupMemberNicknames(memberUids),
                builder: (context, nicknameSnapshot) {
                  final nicknames = nicknameSnapshot.data ?? {};
                  final isLoading =
                      nicknameSnapshot.connectionState == ConnectionState.waiting;
                  return ListView.separated(
                    shrinkWrap: true,
                    itemCount: memberUids.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final memberUid = memberUids[index];
                      final isOwnerRow = memberUid == ownerUid;
                      final isMe = memberUid == currentUid;
                      final nickname = isLoading
                          ? '...'
                          : (nicknames[memberUid] ?? memberUid);
                      final displayName =
                          isMe ? '$nickname (나)' : nickname;
                      return ListTile(
                        leading: CircleAvatar(
                          radius: 18,
                          backgroundColor:
                              AppTheme.primaryColor.withValues(alpha: 0.15),
                          child: Text(
                            nickname.isNotEmpty
                                ? nickname[0].toUpperCase()
                                : '?',
                            style: const TextStyle(
                              color: AppTheme.primaryColor,
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                            ),
                          ),
                        ),
                        title: Text(
                          isOwnerRow ? '$displayName 👑' : displayName,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: isOwnerRow
                            ? const Text('이 소그룹의 관리자입니다.')
                            : null,
                        trailing: canManage && !isOwnerRow
                            ? IconButton(
                                icon: const Icon(
                                  Icons.person_remove_rounded,
                                  color: Colors.redAccent,
                                ),
                                onPressed: () async {
                                  await _removeMemberFromGroup(
                                    context: ctx,
                                    groupId: groupId,
                                    memberUid: memberUid,
                                  );
                                  if (ctx.mounted) Navigator.of(ctx).pop();
                                },
                              )
                            : null,
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      );
    },
  );
}

class GroupPage extends StatefulWidget {
  const GroupPage({
    super.key,
    this.onNotification,
    this.onProfile,
    this.notificationCount,
  });

  final VoidCallback? onNotification;
  final VoidCallback? onProfile;
  final int? notificationCount;

  @override
  State<GroupPage> createState() => _GroupPageState();
}

class _GroupPageState extends State<GroupPage> {
  String? _selectedGroupId;

  /// 0 = 이번 주, -1 = 지난 주, 1 = 다음 주
  int _weekOffset = 0;

  String? get _uid => FirebaseAuth.instance.currentUser?.uid;

  Future<void> _openCreateGroupSheet() async {
    final uid = _uid;
    if (uid == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('아직 로그인 정보가 준비되지 않았습니다.\n잠시 후 다시 시도해 주시면 감사하겠습니다.'),
        ),
      );
      return;
    }

    final nameController = TextEditingController();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        final bottomInset = MediaQuery.of(context).viewInsets.bottom;
        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 20,
            bottom: bottomInset + 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '새 소그룹을 만들어 볼까요?',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: '소그룹 이름',
                  hintText: '예: 청년부 3조, 화요 기도 모임',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(16)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('조용히 닫기'),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: () async {
                      final name = nameController.text.trim();
                      if (name.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('소그룹 이름을 한 줄만이라도 적어 주시면 감사하겠습니다.'),
                          ),
                        );
                        return;
                      }

                      final groupId = await _createGroup(name: name, adminUid: uid);
                      if (!mounted) return;

                      Navigator.of(context).pop();

                      setState(() {
                        _selectedGroupId = groupId;
                      });
                    },
                    child: const Text('소그룹 만들기'),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Future<String?> _createGroup({
    required String name,
    required String adminUid,
  }) async {
    try {
      final inviteCode = await _generateUniqueInviteCode();
      final now = DateTime.now();

      final groupRef = await FirebaseFirestore.instance.collection('groups').add({
        'name': name,
        'description': null,
        'owner_uid': adminUid,
        'member_uids': [adminUid],
        'invite_code': inviteCode,
        'created_at': now,
        'updated_at': now,
      });

      // Users 컬렉션에 내가 속한 groupIds 추가
      await FirebaseFirestore.instance
          .collection('users')
          .doc(adminUid)
          .set(
        {
          'group_ids': FieldValue.arrayUnion([groupRef.id]),
          'updated_at': now,
        },
        SetOptions(merge: true),
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '소그룹이 만들어졌습니다.\n초대 코드는 $inviteCode 입니다.',
            ),
          ),
        );
      }

      return groupRef.id;
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('소그룹을 만드는 중에 잠시 어려움이 있었습니다.\n조금 뒤에 다시 시도해 주시면 감사하겠습니다.'),
          ),
        );
      }
      return null;
    }
  }

  Future<String> _generateUniqueInviteCode() async {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 헷갈리는 문자 제외
    final rand = Random();

    while (true) {
      final code = List.generate(
        6,
        (_) => chars[rand.nextInt(chars.length)],
      ).join();

      final snapshot = await FirebaseFirestore.instance
          .collection('groups')
          .where('invite_code', isEqualTo: code)
          .limit(1)
          .get();

      if (snapshot.docs.isEmpty) {
        return code;
      }
    }
  }

  Future<void> _openJoinGroupSheet() async {
    final uid = _uid;
    if (uid == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('아직 로그인 정보가 준비되지 않았습니다.\n잠시 후 다시 시도해 주시면 감사하겠습니다.'),
        ),
      );
      return;
    }

    final codeController = TextEditingController();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        final bottomInset = MediaQuery.of(context).viewInsets.bottom;
        return Padding(
          padding: EdgeInsets.only(
            left: 16,
            right: 16,
            top: 20,
            bottom: bottomInset + 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '초대 코드를 입력해 주세요.',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: codeController,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  labelText: '초대 코드 (6자리)',
                  hintText: '예: ABC123',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(16)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('조용히 닫기'),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: () async {
                      final code = codeController.text.trim().toUpperCase();
                      if (code.length != 6) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('초대 코드는 6자리로 입력해 주시면 됩니다.'),
                          ),
                        );
                        return;
                      }

                      final joinedGroupId =
                          await _joinGroupWithCode(uid: uid, code: code);
                      if (!mounted) return;

                      Navigator.of(context).pop();

                      if (joinedGroupId != null) {
                        setState(() {
                          _selectedGroupId = joinedGroupId;
                        });
                      }
                    },
                    child: const Text('소그룹 참여하기'),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Future<String?> _joinGroupWithCode({
    required String uid,
    required String code,
  }) async {
    try {
      final query = await FirebaseFirestore.instance
          .collection('groups')
          .where('invite_code', isEqualTo: code)
          .limit(1)
          .get();

      if (query.docs.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('해당 초대 코드를 가진 소그룹을 찾지 못했습니다.\n코드를 다시 한 번만 확인해 주시겠어요?'),
            ),
          );
        }
        return null;
      }

      final groupDoc = query.docs.first;
      final now = DateTime.now();

      await groupDoc.reference.update({
        'member_uids': FieldValue.arrayUnion([uid]),
        'updated_at': now,
      });

      await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .set(
        {
          'group_ids': FieldValue.arrayUnion([groupDoc.id]),
          'updated_at': now,
        },
        SetOptions(merge: true),
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('소그룹 "${groupDoc.data()['name'] ?? ''}" 에 함께 하게 되었습니다.'),
          ),
        );
      }

      return groupDoc.id;
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('소그룹에 참여하는 중에 잠시 어려움이 있었습니다.\n조금 뒤에 다시 시도해 주시면 감사하겠습니다.'),
          ),
        );
      }
      return null;
    }
  }

  Future<void> _leaveGroup({
    required String groupId,
    required bool isOwner,
    required int memberCount,
  }) async {
    final uid = _uid;
    if (uid == null) return;

    if (isOwner && memberCount > 1) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('아직 함께하고 있는 소그룹원이 있어서,\n관리자는 바로 나갈 수 없습니다.\n먼저 멤버 관리에서 다른 분들을 내보내 주세요.'),
        ),
      );
      return;
    }

    try {
      final groupRef =
          FirebaseFirestore.instance.collection('groups').doc(groupId);
      final now = DateTime.now();

      await groupRef.update({
        'member_uids': FieldValue.arrayRemove([uid]),
        'updated_at': now,
      });

      if (memberCount <= 1) {
        // 나가고 나면 더 이상 남는 사람이 없다면 그룹을 정리합니다.
        await groupRef.delete();
      }

      await FirebaseFirestore.instance.collection('users').doc(uid).set(
        {
          'group_ids': FieldValue.arrayRemove([groupId]),
          'updated_at': now,
        },
        SetOptions(merge: true),
      );

      if (!mounted) return;

      setState(() {
        _selectedGroupId = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('소그룹에서 조용히 나왔습니다.\n함께했던 시간을 기억하며, 앞으로도 주님 안에서 평안하시길 기도합니다.'),
        ),
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('소그룹을 나오는 중에 잠시 어려움이 있었습니다.\n조금 뒤에 다시 시도해 주시면 감사하겠습니다.'),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = _uid;

    return Scaffold(
      backgroundColor: AppColors.bgLight,
      body: Stack(
        children: [
          Positioned(
            top: AppBanner.totalHeight,
            left: 0,
            right: 0,
            bottom: 0,
            child: Column(
              children: [
                if (uid != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: _openCreateGroupSheet,
                          tooltip: '새 소그룹 만들기',
                          icon: const Icon(Icons.group_add_rounded),
                        ),
                        IconButton(
                          onPressed: _openJoinGroupSheet,
                          tooltip: '초대 코드로 참여',
                          icon: const Icon(Icons.qr_code_2_rounded),
                        ),
                      ],
                    ),
                  ),
                Expanded(
                  child: uid == null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  '아직 로그인 정보가 준비되지 않았습니다.\n'
                  '잠시 후 다시 들어와 주시면 감사하겠습니다.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ),
            )
          : Column(
              children: [
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      const Icon(Icons.groups_rounded, color: AppTheme.textSubtle),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _GroupSelector(
                          uid: uid,
                          selectedGroupId: _selectedGroupId,
                          onGroupChanged: (groupId) {
                            setState(() {
                              _selectedGroupId = groupId;
                            });
                          },
                          onSettingsTap: (groupId) async {
                            final left = await Navigator.push<bool>(
                              context,
                              MaterialPageRoute<bool>(
                                builder: (_) => GroupSettingsPage(
                                  groupId: groupId,
                                  currentUid: uid,
                                  onLeaveGroup: (isOwner, memberCount) =>
                                      _leaveGroup(
                                    groupId: groupId,
                                    isOwner: isOwner,
                                    memberCount: memberCount,
                                  ),
                                ),
                              ),
                            );
                            if (left == true && mounted) {
                              setState(() => _selectedGroupId = null);
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                const Divider(height: 1),
                Expanded(
                  child: _selectedGroupId == null
                      ? Center(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Text(
                              '아직 함께하는 소그룹이 없거나,\n선택된 소그룹이 없습니다.\n\n'
                              '상단에서 소그룹을 선택하시거나,\n새로운 소그룹을 만들어 보셔도 좋습니다.',
                              textAlign: TextAlign.center,
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ),
                        )
                      : Column(
                          children: [
                            _WeekNavigator(
                              weekOffset: _weekOffset,
                              onPrev: () => setState(() => _weekOffset--),
                              onNext: _weekOffset < 0
                                  ? () => setState(() => _weekOffset++)
                                  : null,
                            ),
                            const Divider(height: 1),
                            Expanded(
                              child: _GroupPrayersList(
                                groupId: _selectedGroupId!,
                                weekRange: getWeekRange(_weekOffset),
                              ),
                            ),
                          ],
                        ),
                ),
              ],
            ),
                ),
              ],
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: AppBanner(
              titleLeft: '소그룹',
              titleRight: '기도',
              subtitle: '우리의 기도를 켜는 시간',
              onNotification: widget.onNotification,
              onProfile: widget.onProfile,
              notificationCount: widget.notificationCount,
            ),
          ),
        ],
      ),
    );
  }
}

// ── 소그룹 설정 화면 ─────────────────────────────
class GroupSettingsPage extends StatelessWidget {
  const GroupSettingsPage({
    super.key,
    required this.groupId,
    required this.currentUid,
    required this.onLeaveGroup,
  });

  final String groupId;
  final String currentUid;
  final Future<void> Function(bool isOwner, int memberCount) onLeaveGroup;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('groups')
          .doc(groupId)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData || !snapshot.data!.exists) {
          return Scaffold(
            appBar: AppBar(title: const Text('소그룹 설정')),
            body: const Center(child: CircularProgressIndicator()),
          );
        }

        final data = snapshot.data!.data() ?? {};
        final name =
            (data['name'] as String?)?.trim().isNotEmpty == true
                ? (data['name'] as String).trim()
                : '소그룹';
        final inviteCode = (data['invite_code'] as String?) ?? '';
        final ownerUid = data['owner_uid'] as String? ?? '';
        final memberUids = (data['member_uids'] as List<dynamic>?)
                ?.map((e) => e.toString())
                .toList() ??
            const <String>[];
        final isOwner = ownerUid == currentUid;
        final memberCount = memberUids.length;

        return Scaffold(
          appBar: AppBar(
            title: Text(name, overflow: TextOverflow.ellipsis),
            backgroundColor: Colors.transparent,
            foregroundColor: AppTheme.textMain,
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              // 초대 코드
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.key_rounded,
                            size: 20,
                            color: AppTheme.primaryColor,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '초대 코드',
                            style: Theme.of(context)
                                .textTheme
                                .titleSmall
                                ?.copyWith(fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              inviteCode.isEmpty ? '—' : inviteCode,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(
                                    letterSpacing: 2,
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.textMain,
                                  ),
                            ),
                          ),
                          FilledButton.icon(
                            onPressed: inviteCode.isEmpty
                                ? null
                                : () async {
                                    await Clipboard.setData(
                                        ClipboardData(text: inviteCode));
                                    if (context.mounted) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        const SnackBar(
                                          content: Text(
                                              '초대 코드가 클립보드에 복사되었습니다.\n함께 기도할 분들과 나눠 보셔도 좋겠습니다.'),
                                        ),
                                      );
                                    }
                                  },
                            icon: const Icon(Icons.copy_rounded, size: 18),
                            label: const Text('복사'),
                            style: FilledButton.styleFrom(
                              backgroundColor: AppTheme.primaryColor,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              // 멤버 관리 / 멤버 목록
              Card(
                child: ListTile(
                  leading: Icon(
                    Icons.people_rounded,
                    color: AppTheme.primaryColor,
                  ),
                  title: Text(
                    isOwner ? '멤버 관리' : '멤버 목록',
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  subtitle: Text(
                    '함께하는 멤버 $memberCount명',
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(color: AppTheme.textSubtle),
                  ),
                  trailing: const Icon(
                    Icons.chevron_right_rounded,
                    color: AppTheme.textSubtle,
                  ),
                  onTap: () {
                    _openGroupMemberSheet(
                      context: context,
                      groupId: groupId,
                      ownerUid: ownerUid,
                      memberUids: memberUids,
                      currentUid: currentUid,
                      canManage: isOwner,
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),
              // 소그룹 나가기
              Card(
                color: Colors.red.shade50,
                child: ListTile(
                  leading: Icon(
                    Icons.logout_rounded,
                    color: Colors.red.shade700,
                  ),
                  title: Text(
                    '이 소그룹 나가기',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.red.shade700,
                    ),
                  ),
                  subtitle: Text(
                    '나가시면 이 소그룹의 기도 제목 목록에 더 이상 접근할 수 없습니다.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.red.shade600,
                        ),
                  ),
                  trailing: Icon(
                    Icons.chevron_right_rounded,
                    color: Colors.red.shade700,
                  ),
                  onTap: () async {
                    final confirm = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        title: const Text('소그룹을 나가시겠어요?'),
                        content: const Text(
                          '나가시면 이 소그룹의 기도 제목 목록에 더 이상 접근할 수 없습니다.\n'
                          '함께했던 시간을 기억하며, 앞으로도 주님 안에서 평안하시길 기도합니다.',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(false),
                            child: const Text('머무르기'),
                          ),
                          TextButton(
                            onPressed: () => Navigator.of(ctx).pop(true),
                            child: Text(
                              '나가기',
                              style: TextStyle(
                                color: Colors.red.shade700,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                    if (confirm != true || !context.mounted) return;
                    await onLeaveGroup(isOwner, memberCount);
                    if (context.mounted) Navigator.of(context).pop(true);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ── 주간 네비게이터 ─────────────────────────────
class _WeekNavigator extends StatelessWidget {
  const _WeekNavigator({
    required this.weekOffset,
    required this.onPrev,
    this.onNext,
  });

  final int weekOffset;
  final VoidCallback onPrev;
  final VoidCallback? onNext;

  @override
  Widget build(BuildContext context) {
    final range = getWeekRange(weekOffset);
    final label = formatWeekLabel(range);
    final isCurrentWeekNow = isCurrentWeek(weekOffset);

    return Container(
      color: const Color(0xFFFFF8F0),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            onPressed: onPrev,
            icon: const Icon(Icons.chevron_left_rounded),
            tooltip: '이전 주',
            color: AppTheme.textMain,
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      color: AppTheme.textMain,
                      fontWeight: FontWeight.w600,
                    ),
              ),
              if (isCurrentWeekNow)
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      '이번 주',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: AppTheme.primaryColor,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ),
                ),
            ],
          ),
          IconButton(
            onPressed: onNext,
            icon: Icon(
              Icons.chevron_right_rounded,
              color: onNext != null ? AppTheme.textMain : AppTheme.textSubtle,
            ),
            tooltip: '다음 주',
          ),
        ],
      ),
    );
  }
}

class _GroupSelector extends StatelessWidget {
  const _GroupSelector({
    required this.uid,
    required this.selectedGroupId,
    required this.onGroupChanged,
    this.onSettingsTap,
  });

  final String uid;
  final String? selectedGroupId;
  final ValueChanged<String?> onGroupChanged;
  final void Function(String groupId)? onSettingsTap;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('groups')
          .where('member_uids', arrayContains: uid)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Text(
            '소그룹 정보를 불러오는 중입니다. 잠시만 기다려 주세요.',
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(color: AppTheme.textSubtle),
          );
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return Row(
            children: const [
              SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
              SizedBox(width: 8),
              Text('소그룹을 불러오는 중입니다...'),
            ],
          );
        }

        final groups = snapshot.data?.docs ?? const [];
        if (groups.isEmpty) {
          return Text(
            '아직 함께하는 소그룹이 없습니다.',
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(color: AppTheme.textSubtle),
          );
        }

        // 선택된 그룹이 없으면 첫 번째 그룹을 기본 선택
        final currentSelectedId = selectedGroupId ?? groups.first.id;
        if (selectedGroupId == null) {
          // 부모 상태 갱신
          WidgetsBinding.instance.addPostFrameCallback((_) {
            onGroupChanged(groups.first.id);
          });
        }

        return Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: DropdownButton<String>(
                value: currentSelectedId,
                isExpanded: true,
                underline: const SizedBox(),
                items: groups.map((doc) {
                  final data = doc.data();
                  final name = (data['name'] as String?) ?? '이름 없는 소그룹';
                  return DropdownMenuItem<String>(
                    value: doc.id,
                    child: Text(
                      name,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );
                }).toList(),
                onChanged: onGroupChanged,
              ),
            ),
            if (onSettingsTap != null) ...[
              const SizedBox(width: 4),
              IconButton(
                onPressed: () => onSettingsTap!(currentSelectedId),
                icon: const Icon(Icons.settings_rounded),
                tooltip: '소그룹 설정',
                style: IconButton.styleFrom(
                  foregroundColor: AppTheme.textSubtle,
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}

class _GroupPrayersList extends StatelessWidget {
  const _GroupPrayersList({
    required this.groupId,
    required this.weekRange,
  });

  final String groupId;
  final WeekRange weekRange;

  DateTime _todt(dynamic v) {
    if (v is Timestamp) return v.toDate();
    if (v is DateTime) return v;
    return DateTime.fromMillisecondsSinceEpoch(0);
  }

  @override
  Widget build(BuildContext context) {
    // 현재 그룹 멤버 목록을 실시간으로 구독 (탈퇴 사용자 판별용)
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('groups')
          .doc(groupId)
          .snapshots(),
      builder: (context, groupSnapshot) {
        final memberUids =
            ((groupSnapshot.data?.data()?['member_uids'] as List<dynamic>?)
                    ?.map((e) => e.toString())
                    .toSet()) ??
                const <String>{};

        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance
              .collection('group_prayers')
              .where('group_id', isEqualTo: groupId)
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    '함께 나눈 기도 제목을 불러오는 중에\n잠시 어려움이 있었습니다.\n\n'
                    '조금 뒤에 다시 시도해 주시면 감사하겠습니다.',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
              );
            }

            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            // 주간 필터링 (client-side, created_at 기준)
            final allDocs = snapshot.data?.docs ?? const [];
            final filtered = allDocs.where((doc) {
              final created = _todt(doc.data()['created_at']);
              return !created.isBefore(weekRange.start) &&
                  !created.isAfter(weekRange.end);
            }).toList();

            if (filtered.isEmpty) {
              return Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    '이번 주에 함께 나눈 기도 제목이 아직 없습니다.\n'
                    '나의 골방에서 기도 제목을 소그룹에 공유해 보셔도 좋습니다.',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
              );
            }

            // 핀 우선, 그 다음 최신순 정렬
            filtered.sort((a, b) {
              final aPinned = (a.data()['is_pinned'] as bool?) ?? false;
              final bPinned = (b.data()['is_pinned'] as bool?) ?? false;
              if (aPinned != bPinned) return aPinned ? -1 : 1;
              return _todt(b.data()['created_at'])
                  .compareTo(_todt(a.data()['created_at']));
            });

            return ListView.separated(
              padding: const EdgeInsets.only(top: 8, bottom: 120),
              itemCount: filtered.length,
              separatorBuilder: (_, __) => const SizedBox(height: 0),
              itemBuilder: (context, index) {
                final gpDoc = filtered[index];
                final data = gpDoc.data();
                final prayerId = data['prayer_id'] as String?;

                if (prayerId == null || prayerId.isEmpty) {
                  return const SizedBox.shrink();
                }

                return _GroupPrayerTile(
                  prayerId: prayerId,
                  groupPrayerId: gpDoc.id,
                  groupPrayerData: data,
                  currentMemberUids: memberUids,
                  currentUid:
                      FirebaseAuth.instance.currentUser?.uid ?? '',
                );
              },
            );
          },
        );
      },
    );
  }
}

class _GroupPrayerTile extends StatelessWidget {
  const _GroupPrayerTile({
    required this.prayerId,
    required this.groupPrayerId,
    required this.groupPrayerData,
    required this.currentMemberUids,
    required this.currentUid,
  });

  final String prayerId;
  final String groupPrayerId;
  final Map<String, dynamic> groupPrayerData;
  final Set<String> currentMemberUids;
  final String currentUid;

  @override
  Widget build(BuildContext context) {
    // StreamBuilder로 변경: prayers 수정 시 그룹 피드에도 실시간 반영
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance
          .collection('prayers')
          .doc(prayerId)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const ListTile(
            title: Text('기도 제목을 불러오는 중입니다...'),
          );
        }

        if (snapshot.hasError || !snapshot.hasData || !snapshot.data!.exists) {
          return const ListTile(
            title: Text('기도 제목 정보를 찾지 못했습니다.'),
          );
        }

        final prayerData = snapshot.data!.data() ?? {};
        final title = (prayerData['title'] as String?)?.trim() ?? '';
        final content = (prayerData['content'] as String?)?.trim() ?? '';
        final ownerUid = (prayerData['owner_uid'] as String?) ?? '';
        final fallbackNickname =
            (prayerData['owner_nickname'] as String?)?.trim() ?? '';
        final statusRaw = prayerData['status'] as String?;

        final statusLabel = _statusLabel(statusRaw);
        final statusBg = _statusBg(statusRaw);

        final createdAt = prayerData['created_at'];
        DateTime? createdAtTime;
        if (createdAt is Timestamp) {
          createdAtTime = createdAt.toDate();
        } else if (createdAt is DateTime) {
          createdAtTime = createdAt;
        }

        final holdCount = (groupPrayerData['hold_count'] as int?) ?? 0;
        final isPinned = (groupPrayerData['is_pinned'] as bool?) ?? false;
        final heldByUids =
            (groupPrayerData['held_by_uids'] as List<dynamic>?)
                ?.map((e) => e.toString())
                .toList() ??
            const <String>[];
        final prayedByMe = currentUid.isNotEmpty && heldByUids.contains(currentUid);

        // 탈퇴 사용자 여부 판별 (그룹에 멤버가 존재하는 경우에만 유효)
        final isFormerMember = currentMemberUids.isNotEmpty &&
            ownerUid.isNotEmpty &&
            !currentMemberUids.contains(ownerUid);

        // users 컬렉션에서 닉네임 실시간 동기화 (탈퇴 사용자는 조회 생략)
        return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          stream: (!isFormerMember && ownerUid.isNotEmpty)
              ? FirebaseFirestore.instance
                  .collection('users')
                  .doc(ownerUid)
                  .snapshots()
              : const Stream.empty(),
          builder: (context, userSnapshot) {
            final nickname = isFormerMember
                ? '탈퇴한 사용자'
                : ownerUid.isNotEmpty
                    ? ((userSnapshot.data?.data()?['nickname'] as String?)
                            ?.trim() ??
                        fallbackNickname)
                    : fallbackNickname;

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 작성자 닉네임 + 핀 버튼
                Row(
                  children: [
                    if (nickname.isNotEmpty) ...[
                      Icon(
                        isFormerMember
                            ? Icons.person_off_outlined
                            : Icons.person_outline_rounded,
                        size: 14,
                        color: isFormerMember
                            ? AppTheme.textSubtle.withValues(alpha: 0.6)
                            : AppTheme.textSubtle,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        nickname,
                        style: Theme.of(context)
                            .textTheme
                            .labelSmall
                            ?.copyWith(
                              color: isFormerMember
                                  ? AppTheme.textSubtle.withValues(alpha: 0.6)
                                  : AppTheme.textSubtle,
                              fontStyle: isFormerMember
                                  ? FontStyle.italic
                                  : FontStyle.normal,
                            ),
                      ),
                    ],
                    const Spacer(),
                    GestureDetector(
                      onTap: () => _toggleGroupPrayerPin(groupPrayerId, isPinned, context),
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: Icon(
                          isPinned
                              ? Icons.push_pin_rounded
                              : Icons.push_pin_outlined,
                          size: 18,
                          color: isPinned
                              ? AppTheme.primaryColor
                              : AppTheme.textSubtle,
                        ),
                      ),
                    ),
                  ],
                ),
                if (nickname.isNotEmpty) const SizedBox(height: 6),
                // 제목 + 상태 칩
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (isPinned)
                      Padding(
                        padding: const EdgeInsets.only(right: 6, top: 2),
                        child: Icon(
                          Icons.push_pin_rounded,
                          size: 14,
                          color: AppTheme.primaryColor,
                        ),
                      ),
                    Expanded(
                      child: Text(
                        title.isEmpty ? '(제목 없음)' : title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: statusBg,
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        statusLabel,
                        style: Theme.of(context)
                            .textTheme
                            .labelSmall
                            ?.copyWith(color: AppTheme.textMain),
                      ),
                    ),
                  ],
                ),
                // 내용
                if (content.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  _ExpandableText(text: content),
                ],
                const SizedBox(height: 12),
                Row(
                  children: [
                    if (createdAtTime != null)
                      Text(
                        _formatDate(createdAtTime),
                        style: Theme.of(context)
                            .textTheme
                            .labelMedium
                            ?.copyWith(color: AppTheme.textSubtle),
                      ),
                    const Spacer(),
                    _HoldPrayerButton(
                      groupPrayerId: groupPrayerId,
                      holdCount: holdCount,
                      currentUid: currentUid,
                      prayedByMe: prayedByMe,
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
          }, // users StreamBuilder builder 닫기
        ); // users StreamBuilder 닫기
      },
    );
  }

  Future<void> _toggleGroupPrayerPin(
      String gpId, bool currentPinned, BuildContext context) async {
    try {
      await FirebaseFirestore.instance
          .collection('group_prayers')
          .doc(gpId)
          .update({
        'is_pinned': !currentPinned,
        'updated_at': DateTime.now(),
      });
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('고정 설정 중에 잠시 어려움이 있었습니다.\n조금 뒤에 다시 시도해 주시면 감사하겠습니다.'),
        ),
      );
    }
  }

  String _statusLabel(String? raw) {
    switch (raw) {
      case 'praying':   return '기도 중';
      case 'answered': return '응답 받음';
      case 'waiting':  return '기다리는 중';
      case 'refocused': return '방향 전환';
      case 'resting':  return '잠시 멈춤';
      case 'in_progress': return '방향 전환';
      default:         return '기도 중';
    }
  }

  Color _statusBg(String? raw) {
    // cross_prayer_note 톤과 동일한 상태 배경색
    switch (raw) {
      case 'praying':   return const Color(0xFFE8D5C4);
      case 'answered':  return const Color(0xFFD4E5CE);
      case 'waiting':   return const Color(0xFFE5E0D8);
      case 'refocused': return const Color(0xFFDDE5E9);
      case 'resting':   return const Color(0xFFF0E2D4);
      case 'in_progress': return const Color(0xFFDDE5E9);
      default:          return const Color(0xFFE8D5C4);
    }
  }
}

/// cross_prayer_note 스타일: 🙏 기도했어요 + 카운트, 미선택/선택 시 테두리·배경·폰트 구분
class _HoldPrayerButton extends StatelessWidget {
  const _HoldPrayerButton({
    required this.groupPrayerId,
    required this.holdCount,
    required this.currentUid,
    required this.prayedByMe,
  });

  final String groupPrayerId;
  final int holdCount;
  final String currentUid;
  final bool prayedByMe;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        if (groupPrayerId.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('기도 붙들기 정보를 찾지 못했습니다.')),
          );
          return;
        }
        final messenger = ScaffoldMessenger.of(context);
        try {
          final ref = FirebaseFirestore.instance
              .collection('group_prayers')
              .doc(groupPrayerId);

          final updates = <String, dynamic>{
            'hold_count': FieldValue.increment(1),
            'last_held_at': DateTime.now(),
          };
          if (currentUid.isNotEmpty) {
            updates['held_by_uids'] = FieldValue.arrayUnion([currentUid]);
          }

          await ref.update(updates);
          debugPrint('[기도 붙들기] gpId=$groupPrayerId uid=$currentUid');

          messenger.showSnackBar(
            const SnackBar(
                content:
                    Text('이 기도 제목을 함께 붙들어 올려 주셔서 감사합니다.')),
          );
        } catch (e) {
          debugPrint('[기도 붙들기] 오류: $e');
          messenger.showSnackBar(
            const SnackBar(
                content: Text(
                    '기도를 붙드는 중에 잠시 어려움이 있었습니다.\n조금 뒤에 다시 시도해 주시면 감사하겠습니다.')),
          );
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        decoration: BoxDecoration(
          color: prayedByMe
              ? AppColors.primary.withValues(alpha: 0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: prayedByMe
                ? AppColors.primary
                : AppColors.textMuted.withValues(alpha: 0.3),
            width: 1.5,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🙏', style: TextStyle(fontSize: 14)),
            const SizedBox(width: 6),
            Text(
              prayedByMe ? '기도했어요 ✓ ($holdCount)' : '기도했어요 ($holdCount)',
              style: TextStyle(
                fontSize: 13,
                color: prayedByMe
                    ? AppColors.primary
                    : AppColors.textLight,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String _formatDate(DateTime date) {
  final y = date.year.toString().padLeft(4, '0');
  final m = date.month.toString().padLeft(2, '0');
  final d = date.day.toString().padLeft(2, '0');
  return '$y.$m.$d';
}

// ── 더보기 토글 텍스트 ──────────────────────────
class _ExpandableText extends StatefulWidget {
  const _ExpandableText({required this.text});

  final String text;
  static const int maxLines = 4;

  @override
  State<_ExpandableText> createState() => _ExpandableTextState();
}

class _ExpandableTextState extends State<_ExpandableText> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final textStyle = Theme.of(context).textTheme.bodyMedium;
    return LayoutBuilder(
      builder: (context, constraints) {
        final tp = TextPainter(
          text: TextSpan(text: widget.text, style: textStyle),
          maxLines: _ExpandableText.maxLines,
          textDirection: TextDirection.ltr,
        )..layout(maxWidth: constraints.maxWidth);
        final isOverflow = tp.didExceedMaxLines;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AnimatedSize(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeInOut,
              alignment: Alignment.topLeft,
              child: Text(
                widget.text,
                maxLines: _expanded ? null : _ExpandableText.maxLines,
                overflow:
                    _expanded ? TextOverflow.visible : TextOverflow.ellipsis,
                style: textStyle,
              ),
            ),
            if (isOverflow || _expanded) ...[
              const SizedBox(height: 4),
              GestureDetector(
                onTap: () => setState(() => _expanded = !_expanded),
                child: Text(
                  _expanded ? '접기' : '더보기',
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(
                        color: AppTheme.primaryColor,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}

