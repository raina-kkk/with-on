import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../services/notification_service.dart';
import '../widgets/app_banner.dart';

// ── 나의 발자국 탭: 차트·통계칩·7일 차트 색상 ──
// [현재] cross_prayer_note 톤
const _kPeach = Color(0xFFC4956A);
const _kSkyBlue = Color(0xFF8FA4B0);
const _kSageGreen = Color(0xFF7B9E6B);
const _kLavender = Color(0xFFD4A574);
const _kStatusChartConfig = [
  ('기도 중', Color(0xFFC4956A)),
  ('응답 받음', Color(0xFF7B9E6B)),
  ('기다리는 중', Color(0xFFA0937D)),
  ('방향 전환', Color(0xFF8FA4B0)),
  ('잠시 멈춤', Color(0xFFD4A574)),
];
// [비교용] 기존 나의 발자국 밝은 톤 — 복원 시 위 상수들을 아래로 교체
// const _kPeach = Color(0xFFE8916C);
// const _kSkyBlue = Color(0xFF7AAEC8);
// const _kSageGreen = Color(0xFF6BAD8C);
// const _kLavender = Color(0xFF9B7DBE);
// const _kStatusChartConfig = [
//   ('기도 중', Color(0xFFE8916C)),
//   ('응답 받음', Color(0xFF6BAD8C)),
//   ('기다리는 중', Color(0xFF7AAEC8)),
//   ('방향 전환', Color(0xFF9B7DBE)),
//   ('잠시 멈춤', Color(0xFF9E9E9E)),
// ];

// ── 데이터 클래스 ──────────────────────────────
class _PrayerStats {
  final int thisWeek;
  final int thisMonth;
  final int totalAnswered;
  final int totalAll;
  final int participatedCount;
  final List<int> last7Days;
  /// 5가지 상태별 개수: [praying, answered, waiting, refocused, resting]
  final List<int> statusCounts;

  const _PrayerStats({
    required this.thisWeek,
    required this.thisMonth,
    required this.totalAnswered,
    required this.totalAll,
    required this.participatedCount,
    required this.last7Days,
    required this.statusCounts,
  });

  static _PrayerStats empty() => const _PrayerStats(
        thisWeek: 0,
        thisMonth: 0,
        totalAnswered: 0,
        totalAll: 0,
        participatedCount: 0,
        last7Days: [0, 0, 0, 0, 0, 0, 0],
        statusCounts: [0, 0, 0, 0, 0],
      );
}

// ── 페이지 ─────────────────────────────────────
class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  // 닉네임
  String? _nickname;
  bool _isLoadingNickname = true;

  // 알림 설정
  bool _notifEnabled = false;
  TimeOfDay _notifTime = const TimeOfDay(hour: 8, minute: 0);
  bool _isNotifLoading = true;

  // 통계 — StreamSubscription으로 실시간 갱신
  _PrayerStats? _stats;
  bool _isStatsLoading = true;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _prayersSub;

  @override
  void initState() {
    super.initState();
    _loadNickname();
    _loadNotificationSettings();
    _subscribeToStats();
  }

  @override
  void dispose() {
    _prayersSub?.cancel();
    super.dispose();
  }

  // ── 닉네임 ─────────────────────────────────────
  Future<void> _loadNickname() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      if (mounted) setState(() => _isLoadingNickname = false);
      return;
    }
    final doc = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .get();
    if (mounted) {
      setState(() {
        _nickname = (doc.data()?['nickname'] as String?)?.trim();
        _isLoadingNickname = false;
      });
    }
  }

  Future<void> _openChangeNicknameDialog() async {
    final controller = TextEditingController(text: _nickname ?? '');
    final newNickname = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('닉네임 변경'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '소그룹에서 보여지는 이름을 변경합니다.',
              style: Theme.of(ctx).textTheme.bodySmall?.copyWith(
                    color: AppTheme.textSubtle,
                  ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              autofocus: true,
              decoration: const InputDecoration(
                labelText: '새 닉네임',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(12)),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('취소'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('변경하기'),
          ),
        ],
      ),
    );

    if (newNickname == null ||
        newNickname.isEmpty ||
        newNickname == _nickname) {
      return;
    }
    await _updateNickname(newNickname);
  }

  Future<void> _updateNickname(String newNickname) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;
    try {
      final now = DateTime.now();
      await FirebaseFirestore.instance.collection('users').doc(uid).update({
        'nickname': newNickname,
        'updated_at': now,
      });
      final prayersQuery = await FirebaseFirestore.instance
          .collection('prayers')
          .where('owner_uid', isEqualTo: uid)
          .get();
      if (prayersQuery.docs.isNotEmpty) {
        final batch = FirebaseFirestore.instance.batch();
        for (final doc in prayersQuery.docs) {
          batch.update(doc.reference, {
            'owner_nickname': newNickname,
            'updated_at': now,
          });
        }
        await batch.commit();
      }
      if (mounted) {
        setState(() => _nickname = newNickname);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('닉네임이 변경되었습니다.\n기존 기도 카드에도 반영되었습니다.')));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text(
                '닉네임 변경 중에 잠시 어려움이 있었습니다.\n조금 뒤에 다시 시도해 주시면 감사하겠습니다.')));
      }
    }
  }

  // ── 실시간 통계 구독 ─────────────────────────
  void _subscribeToStats() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      if (mounted) setState(() => _isStatsLoading = false);
      return;
    }

    // 기존 구독 해제 후 재시작
    _prayersSub?.cancel();
    _prayersSub = FirebaseFirestore.instance
        .collection('prayers')
        .where('owner_uid', isEqualTo: uid)
        .snapshots()
        .listen(
      (snapshot) async {
        debugPrint('[통계] prayers 변경 감지: ${snapshot.docs.length}건');
        await _computeStats(uid, snapshot.docs);
      },
      onError: (e) {
        debugPrint('[통계] 스트림 오류: $e');
        if (mounted) setState(() => _isStatsLoading = false);
      },
    );
  }

  Future<void> _computeStats(
    String uid,
    List<QueryDocumentSnapshot<Map<String, dynamic>>> prayerDocs,
  ) async {
    try {
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final startOfWeek =
          today.subtract(Duration(days: today.weekday - 1)); // 이번 주 월요일
      final startOfMonth = DateTime(now.year, now.month, 1);
      final sevenDaysAgo = today.subtract(const Duration(days: 6));

      int weekCount = 0;
      int monthCount = 0;
      int answeredCount = 0;
      final last7 = List<int>.filled(7, 0);
      final statusCounts = List<int>.filled(5, 0); // praying, answered, waiting, refocused, resting

      for (final doc in prayerDocs) {
        final data = doc.data();
        final createdAt = _toDateTime(data['created_at']);
        final createdDay =
            DateTime(createdAt.year, createdAt.month, createdAt.day);
        final status = data['status'] as String?;

        if (!createdDay.isBefore(startOfWeek)) weekCount++;
        if (!createdDay.isBefore(startOfMonth)) monthCount++;
        if (status == 'answered') answeredCount++;

        final dayIndex = createdDay.difference(sevenDaysAgo).inDays;
        if (dayIndex >= 0 && dayIndex <= 6) last7[dayIndex]++;

        final statusIndex = _statusToIndex(status);
        if (statusIndex >= 0 && statusIndex < 5) statusCounts[statusIndex]++;
      }

      // 기도 붙들기 참여 횟수 (held_by_uids 배열에 내 uid가 포함된 문서 수)
      final holdSnap = await FirebaseFirestore.instance
          .collection('group_prayers')
          .where('held_by_uids', arrayContains: uid)
          .get();
      final participatedCount = holdSnap.docs.length;

      debugPrint('[통계] 이번주=$weekCount, 이번달=$monthCount, '
          '응답=$answeredCount, 참여=$participatedCount');

      if (mounted) {
        setState(() {
          _stats = _PrayerStats(
            thisWeek: weekCount,
            thisMonth: monthCount,
            totalAnswered: answeredCount,
            totalAll: prayerDocs.length,
            participatedCount: participatedCount,
            last7Days: last7,
            statusCounts: statusCounts,
          );
          _isStatsLoading = false;
        });
      }
    } catch (e) {
      debugPrint('[통계] 계산 오류: $e');
      if (mounted) setState(() => _isStatsLoading = false);
    }
  }

  // ── 알림 설정 ───────────────────────────────────
  Future<void> _loadNotificationSettings() async {
    final settings = await NotificationService.instance.loadSettings();
    if (mounted) {
      setState(() {
        _notifEnabled = settings.enabled;
        _notifTime = settings.time;
        _isNotifLoading = false;
      });
    }
  }

  Future<void> _toggleNotification(bool value) async {
    // 웹·미지원 환경에서는 토글 상태만 저장하고 안내 메시지 표시
    if (kIsWeb) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text(
                '로컬 알림은 Android / iOS 앱에서만 지원됩니다.\n'
                '스마트폰 앱으로 설치 후 사용해 주세요.')));
      }
      return;
    }

    if (value) {
      final granted = await NotificationService.instance.requestPermissions();
      if (!granted) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text(
                  '알림 권한이 필요합니다.\n기기 설정에서 알림을 허용해 주시면 감사하겠습니다.')));
        }
        return;
      }
      await NotificationService.instance.scheduleDailyReminder(_notifTime);
      await NotificationService.instance
          .saveSettings(enabled: true, time: _notifTime);
      // 디버그: 예약된 알림 확인
      await NotificationService.instance.debugPendingNotifications();
      if (mounted) {
        setState(() => _notifEnabled = true);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(
                '매일 ${_notifTime.format(context)}에 기도 알림을 드리겠습니다.')));
      }
    } else {
      await NotificationService.instance.cancelReminder();
      await NotificationService.instance
          .saveSettings(enabled: false, time: _notifTime);
      if (mounted) setState(() => _notifEnabled = false);
    }
  }

  Future<void> _changeNotificationTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _notifTime,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppTheme.primaryColor,
              onPrimary: Colors.white,
              surface: AppTheme.backgroundLight,
              onSurface: AppTheme.textMain,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && mounted) {
      setState(() => _notifTime = picked);
      await NotificationService.instance.scheduleDailyReminder(picked);
      await NotificationService.instance
          .saveSettings(enabled: true, time: picked);
      // 디버그: 예약된 알림 확인
      await NotificationService.instance.debugPendingNotifications();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('알림 시간이 ${picked.format(context)}로 변경되었습니다.')));
      }
    }
  }

  // ── 격려 메시지 ─────────────────────────────────
  String _encouragingMessage(int weekCount, int totalAnswered) {
    if (totalAnswered < 10) {
      return '더 많은 기도의 씨앗을 심어보세요!';
    }
    if (weekCount == 0) {
      return '이번 주 첫 기도를 나눠볼까요?\n작은 한 줄이면 충분합니다.';
    } else if (weekCount <= 2) {
      return '조금씩 쌓이는 기도가 아름답습니다.\n이번 주도 잘 하고 계세요.';
    } else if (weekCount <= 5) {
      return '꾸준히 기도하고 계시네요.\n이 발자국이 쌓여 귀한 역사가 됩니다.';
    } else {
      return '이번 주도 하나님 앞에 성실히\n나아가고 계십니다. 정말 귀한 걸음이에요.';
    }
  }

  // ── 빌드 ───────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgLight,
      body: Stack(
        children: [
          Positioned.fill(
            child: RefreshIndicator(
              color: AppTheme.primaryColor,
              onRefresh: () async {
                if (mounted) setState(() => _isStatsLoading = true);
                _subscribeToStats();
              },
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.only(
                  top: AppBanner.totalHeight + 8,
                  left: 0,
                  right: 0,
                  bottom: 40,
                ),
                child: Column(
                  children: [
                    _buildProfileCard(context),
                    _buildStatsCard(context),
                    _buildNotificationCard(context),
                    const SizedBox(height: 8),
                    _buildLogoutButton(context),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: AppBanner(
              titleLeft: 'With',
              titleRight: 'On',
              subtitle: '함께 기도를 켜는 시간',
              onNotification: null,
              onProfile: null,
            ),
          ),
        ],
      ),
    );
  }

  // ── 프로필 카드 ─────────────────────────────────
  Widget _buildProfileCard(BuildContext context) {
    final email = FirebaseAuth.instance.currentUser?.email ?? '';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            CircleAvatar(
              radius: 30,
              backgroundColor: AppTheme.primaryColor.withValues(alpha: 0.18),
              child: Text(
                _nickname?.isNotEmpty == true
                    ? _nickname![0].toUpperCase()
                    : '?',
                style: const TextStyle(
                  color: AppTheme.primaryColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 24,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: _isLoadingNickname
                            ? const SizedBox(
                                height: 14,
                                width: 14,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2),
                              )
                            : Text(
                                _nickname?.isNotEmpty == true
                                    ? _nickname!
                                    : '닉네임 없음',
                                style: Theme.of(context)
                                    .textTheme
                                    .titleMedium
                                    ?.copyWith(fontWeight: FontWeight.w600),
                                overflow: TextOverflow.ellipsis,
                              ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: _openChangeNicknameDialog,
                        child: const Icon(Icons.edit_rounded,
                            size: 18, color: AppTheme.textSubtle),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(email,
                      style: Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.copyWith(color: AppTheme.textSubtle),
                      overflow: TextOverflow.ellipsis),
                  if (_stats != null && !_isStatsLoading)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        '총 기도 ${_stats!.totalAll}개 · '
                        '응답 ${_stats!.totalAnswered}개 · '
                        '참여 ${_stats!.participatedCount}회',
                        style:
                            Theme.of(context).textTheme.labelSmall?.copyWith(
                                  color: AppTheme.primaryColor,
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── 통계 카드 ───────────────────────────────────
  Widget _buildStatsCard(BuildContext context) {
    final stats = _stats ?? _PrayerStats.empty();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 헤더
            Row(
              children: [
                const Icon(Icons.auto_graph_rounded,
                    color: AppTheme.primaryColor, size: 20),
                const SizedBox(width: 8),
                Text('나의 기도 발자국',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w600)),
                const Spacer(),
                // 실시간 갱신 중 인디케이터
                if (_isStatsLoading)
                  const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
              ],
            ),
            const SizedBox(height: 12),

            // 격려 메시지
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: AppTheme.primaryColor.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('💛', style: TextStyle(fontSize: 16)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _encouragingMessage(stats.thisWeek, stats.totalAnswered),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: AppTheme.textMain,
                            height: 1.6,
                          ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 첫 번째 행: 이번 주 | 이번 달
            Row(
              children: [
                Expanded(
                  child: _StatChip(
                    icon: Icons.today_rounded,
                    label: '이번 주',
                    value: '${stats.thisWeek}',
                    unit: '개',
                    color: _kPeach,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _StatChip(
                    icon: Icons.calendar_month_rounded,
                    label: '이번 달',
                    value: '${stats.thisMonth}',
                    unit: '개',
                    color: _kSkyBlue,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // 두 번째 행: 응답받음 | 기도 참여
            Row(
              children: [
                Expanded(
                  child: _StatChip(
                    icon: Icons.check_circle_outline_rounded,
                    label: '응답받음',
                    value: '${stats.totalAnswered}',
                    unit: '개',
                    color: _kSageGreen,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _StatChip(
                    icon: Icons.pan_tool_outlined,
                    label: '기도 참여',
                    value: '${stats.participatedCount}',
                    unit: '회',
                    color: _kLavender,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // 5가지 상태 분포 차트
            Text(
              '기도 상태 분포',
              style: Theme.of(context)
                  .textTheme
                  .labelMedium
                  ?.copyWith(color: AppTheme.textSubtle),
            ),
            const SizedBox(height: 8),
            _StatusDistributionChart(counts: stats.statusCounts),
            const SizedBox(height: 20),

            // 7일 바 차트
            Text(
              '최근 7일 기도 기록',
              style: Theme.of(context)
                  .textTheme
                  .labelMedium
                  ?.copyWith(color: AppTheme.textSubtle),
            ),
            const SizedBox(height: 10),
            SizedBox(
              height: 100,
              child: _WeekActivityChart(dailyCounts: stats.last7Days),
            ),
          ],
        ),
      ),
    );
  }

  // ── 알림 설정 카드 ───────────────────────────────
  Widget _buildNotificationCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.notifications_active_rounded,
                    color: AppTheme.primaryColor, size: 20),
                const SizedBox(width: 8),
                Text('기도 알림 설정',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w600)),
              ],
            ),
            const SizedBox(height: 16),

            // 토글 행
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('매일 기도 알림',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(fontWeight: FontWeight.w500)),
                      const SizedBox(height: 2),
                      Text('정해진 시간마다 조용히 알려드립니다.',
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(color: AppTheme.textSubtle)),
                    ],
                  ),
                ),
                _isNotifLoading
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Switch(
                        value: _notifEnabled,
                        onChanged: _toggleNotification,
                        activeTrackColor: AppTheme.primaryColor,
                        thumbColor: WidgetStateProperty.resolveWith((states) {
                          if (states.contains(WidgetState.selected)) {
                            return Colors.white;
                          }
                          return null;
                        }),
                      ),
              ],
            ),

            // 시간 변경 (활성화 시만 표시)
            AnimatedSize(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeInOut,
              child: _notifEnabled
                  ? Column(
                      children: [
                        const Divider(height: 24),
                        Row(
                          children: [
                            const Icon(Icons.access_time_rounded,
                                size: 18, color: AppTheme.textSubtle),
                            const SizedBox(width: 8),
                            Text('알림 시간',
                                style: Theme.of(context).textTheme.bodyMedium),
                            const Spacer(),
                            GestureDetector(
                              onTap: _changeNotificationTime,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 14, vertical: 8),
                                decoration: BoxDecoration(
                                  color: AppTheme.primaryColor
                                      .withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                      color: AppTheme.primaryColor
                                          .withValues(alpha: 0.3)),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      _notifTime.format(context),
                                      style: const TextStyle(
                                        color: AppTheme.primaryColor,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    const Icon(Icons.edit_rounded,
                                        size: 14,
                                        color: AppTheme.primaryColor),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    )
                  : const SizedBox.shrink(),
            ),
          ],
        ),
      ),
    );
  }

  // ── 로그아웃 버튼 ────────────────────────────────
  Widget _buildLogoutButton(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SizedBox(
        width: double.infinity,
        child: OutlinedButton.icon(
          onPressed: () async {
            final confirm = await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                title: const Text('로그아웃'),
                content: const Text(
                  '정말 로그아웃 하시겠어요?\n언제든지 다시 돌아오실 수 있습니다.',
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(ctx).pop(false),
                    child: const Text('아니요, 계속 있을게요'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.of(ctx).pop(true),
                    child: const Text('네, 나갈게요'),
                  ),
                ],
              ),
            );
            if (confirm == true) {
              await FirebaseAuth.instance.signOut();
            }
          },
          icon: const Icon(Icons.logout_rounded, color: AppTheme.textSubtle),
          label: const Text('로그아웃',
              style: TextStyle(color: AppTheme.textSubtle)),
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: AppTheme.textSubtle),
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16)),
          ),
        ),
      ),
    );
  }
}

// ── 통계 칩 위젯 ───────────────────────────────────
class _StatChip extends StatelessWidget {
  const _StatChip({
    required this.icon,
    required this.label,
    required this.value,
    required this.unit,
    required this.color,
  });

  final IconData icon;
  final String label;
  final String value;
  final String unit;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  color: color,
                  height: 1,
                ),
              ),
              const SizedBox(width: 2),
              Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(
                  unit,
                  style: TextStyle(
                    fontSize: 12,
                    color: color.withValues(alpha: 0.8),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: AppTheme.textSubtle,
                ),
          ),
        ],
      ),
    );
  }
}

// ── 5가지 상태 분포 차트 ───────────────────────
class _StatusDistributionChart extends StatelessWidget {
  const _StatusDistributionChart({required this.counts});

  final List<int> counts;

  @override
  Widget build(BuildContext context) {
    final total = counts.fold<int>(0, (a, b) => a + b);
    final maxCount = total > 0 ? counts.reduce((a, b) => a > b ? a : b) : 1;

    return Column(
      children: List.generate(5, (i) {
        final label = _kStatusChartConfig[i].$1;
        final color = _kStatusChartConfig[i].$2;
        final count = i < counts.length ? counts[i] : 0;
        final widthRatio = maxCount > 0 ? (count / maxCount) : 0.0;

        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(
            children: [
              SizedBox(
                width: 64,
                child: Text(
                  label,
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: AppTheme.textSubtle,
                      ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: widthRatio.clamp(0.0, 1.0),
                    minHeight: 20,
                    backgroundColor: color.withValues(alpha: 0.2),
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                '$count',
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: color,
                    ),
              ),
            ],
          ),
        );
      }),
    );
  }
}

// ── 7일 활동 바 차트 ─────────────────────────────
class _WeekActivityChart extends StatelessWidget {
  const _WeekActivityChart({required this.dailyCounts});

  final List<int> dailyCounts;

  @override
  Widget build(BuildContext context) {
    final maxCount =
        dailyCounts.reduce((a, b) => a > b ? a : b).clamp(1, 9999);
    const maxBarHeight = 56.0;

    final now = DateTime.now();
    const dayNames = ['월', '화', '수', '목', '금', '토', '일'];
    final dayLabels = List.generate(7, (i) {
      final d = now.subtract(Duration(days: 6 - i));
      return dayNames[d.weekday - 1];
    });

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List.generate(7, (i) {
        final count = dailyCounts[i];
        final isToday = i == 6;
        final hasActivity = count > 0;
        final barH =
            (count / maxCount * maxBarHeight).clamp(4.0, maxBarHeight);

        // 파스텔 오렌지 계열
        final barColor = isToday
            ? _kPeach
            : hasActivity
                ? _kPeach.withValues(alpha: 0.45)
                : const Color(0xFFEFE6D6);

        return Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (hasActivity)
                Text(
                  '$count',
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight:
                        isToday ? FontWeight.w700 : FontWeight.normal,
                    color: isToday ? _kPeach : AppTheme.textSubtle,
                  ),
                ),
              const SizedBox(height: 3),
              AnimatedContainer(
                duration: const Duration(milliseconds: 500),
                curve: Curves.easeOutCubic,
                width: double.infinity,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                height: hasActivity ? barH : 4,
                decoration: BoxDecoration(
                  color: barColor,
                  borderRadius: BorderRadius.circular(6),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                dayLabels[i],
                style: TextStyle(
                  fontSize: 11,
                  fontWeight:
                      isToday ? FontWeight.w700 : FontWeight.normal,
                  color: isToday ? _kPeach : AppTheme.textSubtle,
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}

// ── 유틸 ─────────────────────────────────────────
DateTime _toDateTime(dynamic value) {
  if (value is Timestamp) return value.toDate();
  if (value is DateTime) return value;
  return DateTime.fromMillisecondsSinceEpoch(0);
}

/// Firestore status → statusCounts index: praying=0, answered=1, waiting=2, refocused=3, resting=4
int _statusToIndex(String? raw) {
  switch (raw) {
    case 'praying':   return 0;
    case 'answered':  return 1;
    case 'waiting':  return 2;
    case 'refocused': return 3;
    case 'resting':  return 4;
    case 'in_progress': return 3;
    default:         return 0;
  }
}
