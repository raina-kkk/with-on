import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _nicknameController = TextEditingController();

  bool _isSignUpMode = false;
  bool _isLoading = false;
  bool _obscurePassword = true;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _nicknameController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;

    setState(() => _isLoading = true);

    try {
      if (_isSignUpMode) {
        await _signUp();
      } else {
        await _signIn();
      }
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_authErrorMessage(e.code))),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('잠시 연결에 어려움이 있었습니다.\n조금 뒤에 다시 시도해 주시면 감사하겠습니다.'),
        ),
      );
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _signUp() async {
    final credential =
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
      email: _emailController.text.trim(),
      password: _passwordController.text,
    );

    final user = credential.user;
    if (user == null) return;

    final now = DateTime.now();
    await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
      'uid': user.uid,
      'email': user.email ?? '',
      'nickname': _nicknameController.text.trim(),
      'photo_url': null,
      'fcm_token': null,
      'group_ids': <String>[],
      'created_at': now,
      'updated_at': now,
    });
  }

  Future<void> _signIn() async {
    await FirebaseAuth.instance.signInWithEmailAndPassword(
      email: _emailController.text.trim(),
      password: _passwordController.text,
    );
  }

  String _authErrorMessage(String code) {
    switch (code) {
      case 'invalid-email':
        return '이메일 형식이 올바르지 않습니다. 다시 한 번 확인해 주세요.';
      case 'user-not-found':
        return '등록된 계정을 찾지 못했습니다. 이메일을 다시 확인해 주시거나 회원가입을 해 주세요.';
      case 'wrong-password':
      case 'invalid-credential':
        return '이메일 또는 비밀번호가 맞지 않습니다. 다시 한 번 확인해 주시겠어요?';
      case 'email-already-in-use':
        return '이미 사용 중인 이메일입니다. 로그인 화면에서 로그인해 주시면 됩니다.';
      case 'weak-password':
        return '비밀번호는 최소 6자리 이상으로 설정해 주시면 감사하겠습니다.';
      case 'too-many-requests':
        return '잠시 너무 많은 시도가 있었습니다. 조금 후에 다시 시도해 주세요.';
      default:
        return '인증 중에 문제가 발생했습니다. 잠시 후 다시 시도해 주시면 감사하겠습니다.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundLight,
              Color(0xFFF1E0D0),
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 28),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 24),

                    // 로고 및 타이틀
                    Column(
                      children: [
                        Icon(
                          Icons.self_improvement_rounded,
                          size: 64,
                          color: AppTheme.primaryColor,
                        ),
                        const SizedBox(height: 12),
                        Text.rich(
                          TextSpan(
                            text: 'With',
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: AppTheme.textMain,
                                  fontStyle: FontStyle.italic,
                                ),
                            children: [
                              TextSpan(
                                text: ' ; ',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.w700,
                                      color: AppTheme.primaryColor,
                                      fontStyle: FontStyle.italic,
                                    ),
                              ),
                              TextSpan(
                                text: 'On',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.w700,
                                      color: AppTheme.textMain,
                                      fontStyle: FontStyle.italic,
                                    ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _isSignUpMode
                              ? '함께 기도를 나눌 공간에 오신 것을 환영합니다.'
                              : '다시 이 자리에 와 주셔서 감사합니다.',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: AppTheme.textSubtle,
                                    fontStyle: FontStyle.normal,
                                  ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),

                    const SizedBox(height: 36),

                    // 닉네임 (회원가입 모드에서만 표시)
                    if (_isSignUpMode) ...[
                      TextFormField(
                        controller: _nicknameController,
                        decoration: const InputDecoration(
                          labelText: '닉네임',
                          hintText: '소그룹에서 불릴 이름을 정해 주세요.',
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(16)),
                          ),
                          prefixIcon: Icon(Icons.badge_rounded),
                        ),
                        validator: (v) {
                          if (_isSignUpMode &&
                              (v == null || v.trim().isEmpty)) {
                            return '닉네임을 입력해 주시면 감사하겠습니다.';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 14),
                    ],

                    // 이메일
                    TextFormField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        labelText: '이메일',
                        hintText: 'example@email.com',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(16)),
                        ),
                        prefixIcon: Icon(Icons.mail_outline_rounded),
                      ),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) {
                          return '이메일을 입력해 주시면 감사하겠습니다.';
                        }
                        if (!v.contains('@')) {
                          return '올바른 이메일 형식이 아닌 것 같습니다.';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 14),

                    // 비밀번호
                    TextFormField(
                      controller: _passwordController,
                      obscureText: _obscurePassword,
                      decoration: InputDecoration(
                        labelText: '비밀번호',
                        hintText: _isSignUpMode ? '6자리 이상 입력해 주세요.' : '',
                        border: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(16)),
                        ),
                        prefixIcon: const Icon(Icons.lock_outline_rounded),
                        suffixIcon: IconButton(
                          icon: Icon(
                            _obscurePassword
                                ? Icons.visibility_off_rounded
                                : Icons.visibility_rounded,
                          ),
                          onPressed: () {
                            setState(
                                () => _obscurePassword = !_obscurePassword);
                          },
                        ),
                      ),
                      validator: (v) {
                        if (v == null || v.isEmpty) {
                          return '비밀번호를 입력해 주시면 감사하겠습니다.';
                        }
                        if (_isSignUpMode && v.length < 6) {
                          return '비밀번호는 최소 6자리 이상으로 설정해 주세요.';
                        }
                        return null;
                      },
                    ),

                    const SizedBox(height: 28),

                    // 메인 버튼 (로그인 or 회원가입)
                    SizedBox(
                      height: 52,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _submit,
                        child: _isLoading
                            ? const SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.5,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      Colors.white),
                                ),
                              )
                            : Text(
                                _isSignUpMode ? '회원가입하고 시작하기' : '로그인하고 기도 나누기',
                                style: const TextStyle(fontSize: 16),
                              ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // 모드 전환 버튼
                    TextButton(
                      onPressed: _isLoading
                          ? null
                          : () {
                              setState(() {
                                _isSignUpMode = !_isSignUpMode;
                                _formKey.currentState?.reset();
                              });
                            },
                      child: Text(
                        _isSignUpMode
                            ? '이미 계정이 있으신가요?  로그인하기'
                            : '아직 계정이 없으신가요?  회원가입하기',
                        style: TextStyle(
                          color: AppTheme.textSubtle,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
